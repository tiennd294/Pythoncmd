# Listening for new Connected Devices in the Network using DHCP
to run this:
- `pip3 install -r requirements.txt`
-   
    ```
    python3 dhcp_listener.py
    ```