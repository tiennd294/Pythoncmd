# [How to Build a WiFi Scanner in Python using Scapy](https://www.thepythoncode.com/article/building-wifi-scanner-in-python-scapy)
To run this:
- `pip3 install -r requirements.txt`
- Scan nearby networks using `wlan0mon` interface:
    ```
    python wifi_scanner.py wlan0mon
    ```