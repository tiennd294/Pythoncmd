# [Simple Network Scanner](https://www.thepythoncode.com/article/building-network-scanner-using-scapy)
to run this:
- `pip3 install -r requirements.txt`
- 
    ```
    python3 network_scanner.py
    ```