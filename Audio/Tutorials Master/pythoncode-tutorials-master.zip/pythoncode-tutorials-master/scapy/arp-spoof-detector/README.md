# [Detecting ARP Spoof attacks](https://www.thepythoncode.com/article/detecting-arp-spoof-attacks-using-scapy)
to run this:
- `pip3 install -r requirements.txt`
- 
    ```
    python3 detect_arpspoof.py wlan0
    ```