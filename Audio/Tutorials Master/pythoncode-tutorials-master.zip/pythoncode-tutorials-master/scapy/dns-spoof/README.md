# [Writing a DNS Spoofer](https://www.thepythoncode.com/article/make-dns-spoof-python)
To successfully run it, you need:
- Linux machine ( or VM )
- `pip3 install -r requirements.txt`
- Run [ARP Spoof](../arp-spoofer/arp_spoof.py) script against the target.
- Run this script:
    ```
    python3 dns_spoof.py
    ```