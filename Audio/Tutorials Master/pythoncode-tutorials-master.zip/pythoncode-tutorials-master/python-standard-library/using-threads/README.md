# [How to Use Threads to Speed Up your IO Tasks in Python](https://www.thepythoncode.com/article/using-threads-in-python)
To run this:
- `pip3 install -r requirements.txt`