# [How to Work with JSON Files in Python](https://www.thepythoncode.com/article/working-with-json-files-in-python)
To run `example.py`, you have to install `requests` library:
- `pip3 install -r requirements.txt`