# [How to Read Emails in Python](https://www.thepythoncode.com/article/reading-emails-in-python)
Edit `reading_emails.py` on your needs and then run it.