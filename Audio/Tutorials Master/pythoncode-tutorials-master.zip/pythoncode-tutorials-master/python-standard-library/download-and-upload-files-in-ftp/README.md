# [How to Download and Upload Files in FTP Server using Python](https://www.thepythoncode.com/article/download-and-upload-files-in-ftp-server-using-python)
- To upload a file to a FTP server, consider editing `ftp_file_uploader.py` on your needs and run it.
- To download a file, same in `ftp_file_downloader.py`