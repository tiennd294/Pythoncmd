# [How to Access Wikipedia in Python](https://www.thepythoncode.com/article/access-wikipedia-python)
To run this:
- `pip3 install -r requirements.txt`
- `python3 wikipedia_extractor.py`