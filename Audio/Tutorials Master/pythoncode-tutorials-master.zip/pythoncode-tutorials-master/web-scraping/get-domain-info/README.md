# [How to Get Domain Name Information in Python](https://www.thepythoncode.com/article/extracting-domain-name-information-in-python)
To run this:
- `pip3 install -r requirements.txt`
- Use `validate_domains.py` code to validate domains
- Use `get_domain_info.py` code to get various domain information from WHOIS