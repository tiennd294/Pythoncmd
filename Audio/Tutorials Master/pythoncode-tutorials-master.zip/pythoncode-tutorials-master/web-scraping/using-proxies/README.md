# [How to Use Proxies to Anonymize your Browsing and Scraping using Python](https://www.thepythoncode.com/article/using-proxies-using-requests-in-python)
To run this:
- `pip3 install -r requirements.txt`
- If you want to use free available proxies, use `free_proxies.py`
- If you want to use Tor network, make sure Tor is installed in your machine and the service is running. `tor_proxy.py`
- If you want IP rotation on Tor, use `multiple_tor_proxies.py`