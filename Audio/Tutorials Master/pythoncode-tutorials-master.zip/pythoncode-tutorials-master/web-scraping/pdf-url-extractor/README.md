# [How to Extract All PDF Links in Python](https://www.thepythoncode.com/article/extract-pdf-links-with-python)
To run this:
- `pip3 install -r requirements.txt`
- Use `pdf_link_extractor.py` to get clickable links, and `pdf_link_extractor_regex.py` to get links that are in text form.