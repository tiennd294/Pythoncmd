# [How to Convert Text to Speech in Python](https://www.thepythoncode.com/article/convert-text-to-speech-in-python)
- `pip3 install -r requirements.txt`
- To convert text to speech online using Google API, use `tts_google.py`
- To use offline engines in your platform, consider using `tts_pyttsx3.py`
