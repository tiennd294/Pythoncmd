# [Introduction to Finance and Technical Indicators with Python](https://www.thepythoncode.com/article/introduction-to-finance-and-technical-indicators-with-python)
To run this:
- `pip3 install -r requirements.txt`
- Please check [the notebook](technical_indicators.ipynb) or the [Python script](technical_indicators.py)